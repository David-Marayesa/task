export const flip = (id) => {
    return {
        type: "FLIP",
        payload: id
    }
}
